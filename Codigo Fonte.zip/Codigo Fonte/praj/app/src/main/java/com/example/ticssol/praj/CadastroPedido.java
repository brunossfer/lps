package com.example.ticssol.praj;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CadastroPedido extends AppCompatActivity {


    private Button botaoadd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pedido);

        botaoadd = (Button) findViewById(R.id.BotaoAdd);
        botaoadd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openProdutos();
            }
        });



    }

    public void openProdutos(){
        Intent intent = new Intent (this,Produtos.class);
        startActivity(intent);
    }

}
