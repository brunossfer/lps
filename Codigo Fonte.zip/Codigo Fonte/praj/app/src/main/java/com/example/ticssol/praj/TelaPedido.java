package com.example.ticssol.praj;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaPedido extends AppCompatActivity {

    private Button botaoTarefa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pedido);
        botaoTarefa = (Button) findViewById(R.id.BotaoTarefa);
        botaoTarefa.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openTarefas();
            }
        });
    }




    public void openTarefas(){
        Intent intent = new Intent (this,Tarefas.class);
        startActivity(intent);
    }

}
