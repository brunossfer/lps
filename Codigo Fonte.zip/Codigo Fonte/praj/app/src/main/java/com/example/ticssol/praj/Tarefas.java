package com.example.ticssol.praj;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;

public class Tarefas extends AppCompatActivity {


    private CardView card1;
    private CardView card2;
    private CardView card3;
    private FloatingActionButton botaoadd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);


        card1 = (CardView) findViewById(R.id.Card1);
        card1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openTelaTarefa();
            }
        });

        botaoadd = (FloatingActionButton) findViewById(R.id.BotaoAdd);
        botaoadd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openCadastroTarefa();
            }
        });

        card2 = (CardView) findViewById(R.id.Card2);
        card2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openTelaTarefa();
            }
        });

        card3 = (CardView) findViewById(R.id.Card3);
        card3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openTelaTarefa();
            }
        });

    }


    public void openTelaTarefa(){
        Intent intent = new Intent (this,TelaTarefa.class);
        startActivity(intent);
    }

    public void openCadastroTarefa(){
        Intent intent = new Intent (this,CadastroTarefa.class);
        startActivity(intent);
    }

}
