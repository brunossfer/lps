package com.example.ticssol.praj;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CadastrarProduto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_produto);
    }
}
